<?php

    phpinfo();

?>