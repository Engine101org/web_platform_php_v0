<?php

$DB_DSN = 'localhost';
$DB_USER = 'kuzivakw_engine1';
$DB_PASSWORD = 'Simukai5';
$DB_NAME = 'kuzivakw_engine101';

/*
$DB_DSN = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = 'password';
$DB_NAME = 'camagru';
*/

?>